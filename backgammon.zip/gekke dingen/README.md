# jasperStratego
jasper stratego, simpele UI
