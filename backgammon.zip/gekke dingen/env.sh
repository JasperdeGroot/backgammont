# set up the environment to do the testing

PATH='/c/xampp/php/:/I/xampp/php/:'$PATH

phpunit=php.exe
# echo `pwd`/../lib/phpunit.phar
phpunitPhar=`pwd`/phpunit.phar
#phpunitPhar=/z/phpunit.phar